﻿# Set the path where the log files will be saved
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Get the current date and time as a DateTime object
$CurrentDate = Get-Date

# Set the base name for the logs folder
$LogsBaseName = "Logs"

# Set the initial log folder name using the formatted date string
$LogsFolderName = "$LogsBaseName-$(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')"


# Set the path for the log folder
$LogPath = "$ScriptPath\$LogsFolderName"

# Check if a log folder with the same name already exists
$Counter = 0
while (Test-Path -Path $LogPath) {
    $Counter++
    $LogsFolderName = "$LogsBaseName-$CurrentDate-$Counter"
    $LogPath = "$ScriptPath\$LogsFolderName"
}

# Create the log folder if it doesn't exist
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath | Out-Null
}

# Variables to export the dll.config/appsettings.production.json
$DefaultOrchestratorPath = "C:\Program Files (x86)\UiPath\Orchestrator"
Write-Host ''
$OrchestratorPath = Read-Host -Prompt "Press enter if the Orchestrator is installed in the Default location or enter the path of the Orchestrator [default: $DefaultOrchestratorPath]"

if ([string]::IsNullOrEmpty($OrchestratorPath)) {
    $OrchestratorPath = $DefaultOrchestratorPath
}

# Define the paths for the sources and destination
$SourcePath1 = "$OrchestratorPath\UiPath.Orchestrator.dll.config"
$SourcePath2 = "$OrchestratorPath\Identity\Appsettings.Production.json"
$SourcePath3 = "$env:SystemDrive\inetpub\logs\LogFiles"
$DestinationPath = $LogPath

# Create the destination folder if it doesn't exist
if (!(Test-Path -Path $DestinationPath)) {
    New-Item -ItemType Directory -Path $DestinationPath | Out-Null
}

try {
    # Export the dll.config/appsettings.production.json files
    Copy-Item -Path $SourcePath1 -Destination $DestinationPath
    Copy-Item -Path $SourcePath2 -Destination $DestinationPath

    # Get all the log files from the IIS logs folder
    $LogFiles = Get-ChildItem -Path $SourcePath3 -Recurse -File

    # Filter the log files to only include those that have been modified in the last 7 days
    $RecentLogFiles = $LogFiles | Where-Object { $_.LastWriteTime -gt $CurrentDate.AddDays(-7) }

    # Copy the recent log files to the destination folder
    foreach ($LogFile in $RecentLogFiles) {
        $DestinationFile = Join-Path -Path $DestinationPath -ChildPath $LogFile.FullName.Substring($SourcePath3.Length)
        $DestinationDir = [System.IO.Path]::GetDirectoryName($DestinationFile)
        if (-Not (Test-Path -Path $DestinationDir)) {
            New-Item -ItemType Directory -Path $DestinationDir | Out-Null
        }
        Copy-Item -Path $LogFile.FullName -Destination $DestinationFile
    }
} catch {
    Write-Host -ForegroundColor Red "An error occurred while copying files: $_"
}

# Ask the user if they want to gather a network trace
Write-Host ''
$GatherNetworkTrace = $null
while ($null -eq $GatherNetworkTrace) {
    $GatherNetworkTrace = Read-Host -Prompt "Enable network trace? (may take a while) (yes/no)"
    if ($GatherNetworkTrace -notmatch "^(yes|no)$") {
        Write-Host -ForegroundColor Yellow "Invalid input. Please enter 'yes' or 'no'."
        $GatherNetworkTrace = $null
    }
}

if ($GatherNetworkTrace -eq "yes") {
    try {
        # Start network trace using netsh function
        Write-Host -ForegroundColor Green "Starting network trace..."
        $NetworkTracePath = "$LogPath\Network_Trace.etl"
        netsh trace start capture=yes persistent=no traceFile=$NetworkTracePath

        # Wait for the user to reproduce the issue and gather necessary data
        $reproduceIssue = Write-Host -ForegroundColor Green "Please reproduce the issue, press ENTER, and wait for the network trace to be saved. This may take a while if the trace was open for a long time." -NoNewline; Read-Host

        # Stop the network trace using netsh function
        Write-Host -ForegroundColor Green "Stopping network trace..."
        netsh trace stop
    } catch {
        Write-Host -ForegroundColor Red "An error occurred while handling network trace: $_"
    }
}

# Enable the CAPI2 logs
$EventLog = Get-WinEvent -ListLog 'Microsoft-Windows-CAPI2/Operational'
$EventLog.IsEnabled = $true
$EventLog.SaveChanges()

# Set the path to the Platform.Configuration.Tool.ps1 script
$PlatformConfigToolscriptPath = "$OrchestratorPath\Tools\PlatformConfiguration\Platform.Configuration.Tool.ps1"

# Start the transcript of the console session
Start-Transcript -Path "$LogPath\Transcript.log" -Append | Out-Null

# Invoke the Platform.Configuration.Tool.ps1 script with the -Readiness and -SiteName parameters, and redirect the output to a log file in the Logs folder
& $PlatformConfigToolscriptPath -Readiness -SiteName "UiPath Orchestrator"

# Stop the transcript of the console session
Stop-Transcript | Out-Null

# Export the Application log
wevtutil epl Application "$LogPath\Application.evtx"

# Export the Security log
wevtutil epl Security "$LogPath\Security.evtx"

# Export the System log
wevtutil epl System "$LogPath\System.evtx"

# Export the CAPI2 log
wevtutil.exe epl Microsoft-Windows-CAPI2/Operational "$LogPath\CAPI2.evtx"

# Compress the Logs folder into a ZIP archive
Compress-Archive -Path $LogPath -DestinationPath "$LogPath.zip"

# Disable CAPI2 logs
$EventLog = Get-WinEvent -ListLog 'Microsoft-Windows-CAPI2/Operational'
$EventLog.IsEnabled = $false
$EventLog.SaveChanges()

# Delete Logs folder
Remove-Item $LogPath -Recurse -Force

# Display a message telling the user the script is complete and where to find the logs
Write-Host -ForegroundColor Green "The script is now complete. All the information is present in the 'Logs.zip' archive, including the Network Trace if gathered. Please send it over for further analysis."
